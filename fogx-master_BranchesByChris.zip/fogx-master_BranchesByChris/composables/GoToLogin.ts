export  const GotoLoginPage = ()=>{
    navigateTo("/Login")
}