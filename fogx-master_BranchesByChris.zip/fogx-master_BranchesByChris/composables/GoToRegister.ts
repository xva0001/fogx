export const GoToRegisterPage=()=>{
    navigateTo("/register")
}