<template>




</template>
<script setup lang="ts">

const DarkMode = useThemeStore();
const isDark = ref(DarkMode.isDark);



</script>